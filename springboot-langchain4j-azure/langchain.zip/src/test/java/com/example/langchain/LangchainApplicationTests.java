package com.example.langchain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LangchainApplicationTests {

	@Test
	void contextLoads() {
	}

}
